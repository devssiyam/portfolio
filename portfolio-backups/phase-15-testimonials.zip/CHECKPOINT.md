# CHECKPOINT — Siyam Portfolio

## Phase 03 — React Foundation: COMPLETE (verified)

### What was done
Implemented MIGRATION-PLAN.md: scaffolded Vite + React + TypeScript, built one component
per existing section, extracted all repeated logic into hooks, and moved all content into
typed data files — with real content, exact values, and existing behavior preserved. No
section redesign, no generic/template UI, no new functionality added.

- `react-app/` — Vite + React 19 + TypeScript project.
  - `index.html` — same meta/SEO/favicon/fonts as the original, unchanged.
  - `src/styles/style.css` — original stylesheet copied byte-for-byte (diff-verified),
    imported once. No CSS Modules/styled-components introduced.
  - `src/types/content.ts` + `src/data/` — navLinks, typingPhrases, skills, projects,
    services, stats, testimonials, siteConfig. Every value (percents/widths, text, bullets,
    quotes, targets, the two conflicting emails, placeholder `#` links, shared GitHub repo
    URL) carried over exactly as authored.
  - `src/hooks/` — useScrollThreshold, useMediaQuery, useAosReveal, useCountUp, useInView,
    useTypingEffect, useCardTilt, useSmoothScroll — each a direct extraction of the matching
    script.js module's exact logic/timing/easing.
  - `src/components/` — Loader, CustomCursor, Navbar, Hero, About, Skills/SkillCard,
    Projects/ProjectCard, Services/ServiceCard, Stats, Testimonials/TestimonialCard, Contact,
    Footer, BackToTop, ScrollProgressBar, + shared SectionHeader/Button/icons.
  - `src/App.tsx` — wires everything; Loader's onComplete preserves the checkAOS() coupling.

### Explicit decisions made (per plan's own requirement, not resolved silently)
- **Active-nav-link duplication:** kept only module 18 (IntersectionObserver section
  highlight) in Navbar.tsx; dropped module 5 (scroll-position version) as redundant.
- **checkAOS() ↔ loader coupling:** preserved via Loader's `onComplete` prop, called by
  App.tsx exactly where the original called checkAOS() directly.
- **rAF/timeout cleanup (highest risk):** CustomCursor, useTypingEffect, useCardTilt, and
  Hero's orb parallax all have explicit useEffect cleanup. Verified under StrictMode
  (double-invokes effects) with no leaked loops/listeners.

### Known pre-existing issues carried forward unresolved (not fixed this phase)
Two conflicting emails; no real contact-form backend; 7 placeholder `#` links; `cursor:
none` gated by media query not hover/pointer capability; no prefers-reduced-motion; all 6
project GitHub links point to the same repo.

### Verification
- `npx tsc --noEmit` — 0 errors.
- `npm run build` — succeeds (tsc -b && vite build), working dist/ produced.
- `vite preview` served the build successfully (confirmed via curl).
- jsdom smoke test on the production bundle: 0 thrown/console errors, 0 warnings (aside
  from expected font-fetch failures jsdom can't make — not a code defect); all 22
  structural DOM checks passed (every section present; correct counts — 6 nav links, 8
  skill cards, 6 project cards, 5 service cards, 3 testimonials, 4 stats items; loader,
  cursor, back-to-top, typing-text, send button, success message all present); console
  branding log fires on mount.
- `src/styles/style.css` diffed against the original — byte-identical.
- Original index.html/script.js/style.css in this zip's root are unmodified (byte-diff
  verified) — the React app is a parallel implementation, nothing live was touched.
- Test script and dev/preview server processes removed after verification; nothing left
  running. `react-app/` copied into the package excluding node_modules and dist.

### This checkpoint
- ZIP: `portfolio-backups/phase-03-react.zip` — index.html, script.js, style.css
  (unmodified) + AUDIT.md + MIGRATION-PLAN.md + PHASE-03-NOTES.md + full react-app/ source
  (no node_modules, no dist).
- Verified via `unzip -l`: 65 files total, all expected paths present.
- Tests: PASS (typecheck clean, build clean, smoke test all-pass, style.css unchanged).

### Next task
Awaiting Phase 04 instruction (not started, not assumed). Likely candidates when
requested:
- Visual/section redesign work (explicitly deferred until now, per every prior phase).
- Resolving flagged content issues (email conflict, placeholder links, shared repo URL).
- Decision on decorative-module fate (cursor, tilt, parallax) if redesign changes scope.
- prefers-reduced-motion support.
- Real contact-form backend.

## Blocker
None.

## Phase 04 — Content Architecture: COMPLETE (verified — audit, no changes needed)

### What was done
Audited `react-app/src/` for the requested content categories (projects, skills,
services, experience, testimonials) to confirm they live in clean typed data structures
with no repeated content hardcoded in components.

**Finding:** all four real categories were already fully externalized during Phase 03:
- `src/data/projects.ts` (`Project[]`) → `Projects.tsx` → `ProjectCard.tsx`
- `src/data/skills.ts` (`Skill[]`) → `Skills.tsx` → `SkillCard.tsx`
- `src/data/services.ts` (`Service[]`) → `Services.tsx` → `ServiceCard.tsx`
- `src/data/testimonials.ts` (`Testimonial[]`) → `Testimonials.tsx` → `TestimonialCard.tsx`

Grepped every component file for literal strings matching known repeated content
(project titles, skill names) outside `src/data/` — zero matches. No source files were
modified.

**"Experience" — confirmed not present in source.** Re-checked index.html, AUDIT.md, and
MIGRATION-PLAN.md: no experience/timeline/work-history section or repeated experience
content exists anywhere in the original site. The word appears only twice as ordinary
prose ("smooth user experience", "web experiences" in the About bio) — not structured or
repeated content. Per GLOBAL CONTROL's no-invented-content rule, no experience data
structure was created; nothing was fabricated to fill this category.

### Verification
- `npx tsc --noEmit` — 0 errors.
- `npm run build` — succeeds; output bundle hashes (`index-DsR3DQ2X.css`,
  `index-vzjdFBNe.js`) byte-identical to the Phase 03 build, confirming zero functional/
  content change occurred this phase.
- jsdom smoke test targeted at the four affected sections: correct element counts (8
  skill cards, 6 project cards, 5 service cards, 3 testimonials); spot-checked real text
  survived intact (HTML5, Shopify, "Shopify Product Page", "Personal Portfolio Website",
  "Shopify Store Design", "Shakib Khan"); 0 console errors, 0 warnings.
- Test script and jsdom dev-dependency removed after verification.

### This checkpoint
- ZIP: `portfolio-backups/phase-04-content.zip` — index.html, script.js, style.css
  (unmodified) + AUDIT.md + MIGRATION-PLAN.md + PHASE-03-NOTES.md + PHASE-04-NOTES.md +
  full react-app/ source (no node_modules, no dist).
- Verified via `unzip -l`: 66 files total, all expected paths present.
- Tests: PASS (typecheck clean, build clean and byte-identical to Phase 03, content
  smoke test all-pass).

### Next task
Awaiting Phase 05 instruction (not started, not assumed). Likely candidates when
requested:
- Visual/section redesign work (explicitly deferred until now, per every prior phase).
- Resolving flagged content issues (email conflict, placeholder links, shared repo URL).
- Decision on decorative-module fate (cursor, tilt, parallax) if redesign changes scope.
- prefers-reduced-motion support.
- Real contact-form backend.
- If a genuine "experience" section is wanted, it needs real source content supplied
  first — none exists to migrate.

## Blocker (Phase 04)
None.

## Phase 05 — Design Tokens: COMPLETE (verified)

### What was done
Audited `src/styles/style.css`'s existing `:root` token block against actual repeated
values across the file, then extended it additively — no existing rule/token changed,
renamed, or removed; no section redesigned.

**Already existed (unchanged):** color (bg/accent/text/border), 8-step spacing scale,
radius scale, shadow scale, motion (ease/transition), container/nav-height/section-pad.

**Added (new, mirrors values already in repeated use):**
- Semantic `--success` (+glow/bg/border) — was `#22C55E` repeated at 4 unrelated sites.
- Code-snippet syntax palette `--code-keyword/var/op/key/str/comment` (6 colors, hero
  code card).
- Decorative `--dot-red/yellow/green` (macOS traffic-light dots).
- Overlay tones `--overlay-heavy/strong/soft` (was 3 different rgba(15,23,42,X) calls).
- Typography scale `--text-display/h2/h3/h4/body-lg/body/body-sm/caption/micro` — names
  sizes already in use; did NOT rewrite any of the 60 existing font-size declarations.
- Font-weight tokens `--weight-regular/medium/semibold/bold/black`.
- Line-height tokens `--leading-tight/snug/normal/relaxed`.
- Z-index scale `--z-base/nav/nav-overlay/nav-menu/modal/cursor/cursor-follower/loader`.
- Breakpoints (1024/768/480px) — documented as a CSS comment (custom properties can't
  be read inside `@media` conditions) and mirrored as real TS constants in new
  `src/styles/tokens.ts` (`breakpoints`, `mediaQuery`).

### Code changes
- `src/styles/style.css` — one new `:root` block inserted right after the existing one,
  plus a breakpoints reference comment. Diffed: the change is a single contiguous
  insertion, zero pre-existing lines touched.
- `src/styles/tokens.ts` (new) — breakpoint/mediaQuery constants.
- `useCardTilt.ts` + `Hero.tsx` — the two call sites hardcoding `'(max-width: 768px)'`
  now import `mediaQuery.mobile` instead. Same value, same behavior — deduplicates a
  magic string, changes nothing rendered.

### Verification
- Diff-confirmed the style.css change is purely additive (single contiguous insertion).
- Grepped for remaining hardcoded breakpoint literals outside tokens.ts/comments — none.
- `npx tsc --noEmit` — 0 errors.
- `npm run build` — succeeds; CSS hash changed (expected, new `:root` content), JS size
  essentially unchanged (269.02 KB → 269.16 KB).
- jsdom regression smoke test: all structural counts unchanged (loader, navbar, 6 nav
  links, 8 skill cards, 6 project cards, 5 service cards, 3 testimonials, 4 stats,
  contact success element) and 0 console errors. Raw built CSS inspected directly to
  confirm every token compiles to the correct value (minifier lowercases/hex-converts
  but values are identical — e.g. `--overlay-heavy` → `#0f172afa` = exactly
  `rgba(15,23,42,0.98)`).
- Test script and jsdom dev-dependency removed after verification.

### This checkpoint
- ZIP: `portfolio-backups/phase-05-tokens.zip` — index.html, script.js, style.css
  (unmodified originals) + AUDIT.md + MIGRATION-PLAN.md + PHASE-03/04/05-NOTES.md +
  full react-app/ source (no node_modules, no dist).
- Tests: PASS (typecheck clean, build clean, zero visual/structural regressions).

### Next task
Awaiting Phase 06 instruction (not started, not assumed). Likely candidates when
requested:
- Visual/section redesign work, now that a fuller token system exists to redesign with.
- Resolving flagged content issues (email conflict, placeholder links, shared repo URL).
- Decision on decorative-module fate (cursor, tilt, parallax) if redesign changes scope.
- prefers-reduced-motion support.
- Real contact-form backend.
- Retrofitting the 60 existing font-size declarations onto the new type scale, if a
  redesign phase decides that's in scope (deliberately not done here to avoid
  regression risk in a tokens-only phase).

## Blocker (Phase 05)
None.
## Phase 06 — Typography: COMPLETE (verified)

### What was done
Implemented TASK 06: a three-voice type system — **Geist** (headings, nav,
buttons, labels, technical UI), **Inter** (body/supporting text), **Lora**
(selective editorial emphasis only — the testimonial voice) — with
hierarchy, weight, line-height, tracking, measure, and responsive-scaling
refinements. No layout redesign: no grid/padding/container/box-model change;
all content/voice preserved verbatim.

**Files changed: exactly 2** (plus this checkpoint documentation):
- `react-app/index.html` — one Google Fonts request now loads all four
  families as variable fonts with `display=swap` (Geist 500..900, Inter
  300..900, Lora ital 0/1 400..700, Fira Code 300..700). The Fira Code range
  was widened from 400;500 → 300..700 because the typing cursor uses weight
  300 — previously a synthesized weight, now a real one.
- `react-app/src/styles/style.css` — one new labeled block,
  **"1c. TYPOGRAPHY SYSTEM (Phase 06)"**, appended at END of file so it wins
  the cascade. Diff vs the original stylesheet is still purely additive
  (195 added lines total across Phases 05+06, zero pre-existing lines
  touched).

### Explicit decisions made (recorded, not silent)
- **Lora used in exactly one place** — `.testimonial-card__text` + its large
  `.testimonial-card__quote` glyph (was `Georgia` — same decorative role, now
  the real serif voice). Nowhere else; anything more would make serif a
  second body voice, against "selective editorial emphasis only".
- **Fira Code motif preserved** (typing line, code card, loader text,
  floating badges, tag chips, skill %, service numbers) — the code motif is
  established identity per AUDIT.md; "technical UI" is covered by Geist on
  all sans chrome (nav, buttons, labels, tags, numbers).
- **Top-of-file insertion rejected during verification**: built-CSS cascade
  inspection showed original per-section rules would override Phase-06
  weight/line-height/tracking values. Block moved to end of file; built CSS
  confirmed Phase-06 rules win while the §17 responsive `font-size`
  overrides still apply.
- **No display weight 900** — Geist Black is materially wider/heavier than
  Inter Black; hierarchy steps down 800 (h1/numbers/logos) / 700 (h2) /
  600 (card titles + h4s) with sub-px size trims (skill name 0.92→0.95rem,
  project title 1→1.05rem, service title 1.05→1.1rem) and tightened
  display line-heights (1.05 / 1.15) + optical tracking (-0.03em / -0.02em).
- **Fallbacks**: `--font-display` chain is Geist → Inter → system stack (a
  Geist failure degrades to the old look, not a system font); `--font-base`
  re-declared with extended stack (Segoe UI/Roboto/Helvetica Neue);
  `--font-mono` gains ui-monospace/SFMono/Menlo/Consolas; `display=swap`.
- **Measure**: `.about__bio` capped at `62ch` (desktop column ran ~70ch —
  the only width constraint added). **Responsive additions**: ≤768px mobile
  menu links 600 + -0.01em; ≤480px hero/section-title tracking relaxed
  (-0.025em/-0.015em) for Geist's wider metrics.

### Known pre-existing issues carried forward unresolved
Unchanged from prior phases: email conflict; fake contact form; 7
placeholder `#` links; all-6-projects shared repo URL; `cursor: none`
device-class bug; no `prefers-reduced-motion`; testimonial initials (R/S/M)
don't match their names; skill bar `width` ≠ displayed `percent`; `Button.tsx`
dead code; `useAosReveal` dead `rafRef`; 3 lint warnings.

### Verification
- `npx tsc --noEmit` — 0 errors.
- `npm run build` — succeeds. **JS bundle byte-identical to Phase 05
  (269.16 kB) — CSS + HTML font-link change only, zero JS change.** CSS
  32.12 kB → 34.26 kB.
- `npm run lint` — 0 errors, same 3 pre-existing warnings, none new.
- `diff` original vs. react-app style.css — purely additive, 0 lines
  changed/removed.
- Built-CSS cascade inspection — Phase-06 declarations last-in-order for
  `.hero__title`, `.section-title`, `.testimonial-card__text`, `.nav__logo`,
  `.stats__number` (weight/line-height/tracking/size all win).
- jsdom smoke test on the production bundle — **32/32 PASS, 0 console
  errors, 0 warnings**: all structural counts unchanged (6 nav links, 8
  skill cards, 6 project cards, 5 service cards, 3 testimonials, 4 stats,
  loader/cursor/back-to-top/typing/send/success present); all four font
  tokens resolve to Geist/Inter/Lora/Fira Code; computed styles confirm the
  winning cascade (hero title weight 800, section title 700, testimonial
  text .95rem on `--font-serif`, headings/nav/btn/labels on
  `--font-display`, body on `--font-base`, mono motif on `--font-mono`,
  about-bio measure active, font link has all four families + display=swap).
- jsdom installed via `npm install --no-save` — `package.json` /
  `package-lock.json` unmodified; test script run from a temp copy and
  removed.

### This checkpoint
- ZIP: `portfolio-backups/phase-06-type.zip` — index.html, script.js,
  style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06-NOTES.md + full react-app/ source (no node_modules, no
  dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates when
requested:
- Visual/section redesign work (typography is now the foundation to
  redesign against).
- Resolving flagged content issues (email conflict, placeholder links,
  shared repo URL, CV file, testimonial initials).
- Decision on decorative-module fate (cursor, tilt, parallax, typing).
- `prefers-reduced-motion` support.
- Real contact-form backend.

## Blocker (Phase 06)
None.
## Phase 07 — Header: COMPLETE (verified)

### What was done
Redesigned the Header/Navbar only ("the index" concept — the site's
code-editor identity extended into the nav: numbered file-index entries,
square corners, solid surfaces). Identity preserved and refined: the
actual `<SIYAM/>` wordmark (not a template logo) gains a blinking block
caret echoing the hero typing cursor. All 6 real nav sections from
`data/navLinks` with Fira Code indices (01–06). Active state: accent
index + full-width 2px underline growing from the left +
`aria-current="true"`. Scrolled state: solid `var(--bg)` + 1px hairline
(replaces rgba + 20px blur + drop shadow). CTA "Hire Me" (content
kept) reduced from filled banner to a quiet 1px-boxed text link.
Mobile: the 280px blurred slide-out panel is replaced by a full-width
sheet dropping below the 60px header — solid `var(--bg-card-2)`,
numbered entries, "Hire Me →" as the final row (previously absent on
mobile), 0.25s drop+fade with `visibility` gating.

**Accessibility (new):** skip link (first focusable, `href="#main"`,
off-canvas until focused) + `<main id="main" tabIndex={-1}>` (2
attributes in App.tsx, recorded); `useSmoothScroll` returns early for
`.skip-link` so the skip link keeps NATIVE jump+focus (every other
anchor's smooth-scroll behavior byte-identical); hamburger with dynamic
`aria-label`/`aria-expanded`/`aria-controls`; sheet focus management
(focus-in on open, Tab/Shift+Tab trap, focus-returns-to-hamburger on
close via any path); 2px accent `:focus-visible` outlines on all header
controls. Deliberately NO menubar/arrow-key pattern (WAI-ARIA antipattern
for site nav).

**Explicitly avoided (per task):** glass, blur, glow (zero
`backdrop-filter`/`filter: blur`/`box-shadow` in all header rules —
verified in source and built CSS), pills, template logos, oversized CTA,
and common portfolio-nav patterns (dot indicators, center-grow
underlines, side slide-ins, glass bars).

### Files changed
- `src/components/Navbar.tsx` — restructured (skip link, indexed links,
  caret, CTA row inside menu, a11y wiring, focus management).
- `src/styles/style.css` — §7 NAVBAR section rewritten in place (redesign
  = replacement, the point of the task) + 768px "Navbar mobile" block
  rewritten in place. No other line of the stylesheet touched.
- `src/hooks/useSmoothScroll.ts` — 6-line documented skip-link exclusion.
- `src/App.tsx` — `<main id="main" tabIndex={-1}>`.

Not touched: legacy `P5/index.html|script.js|style.css` (git-clean),
`ScrollProgressBar` (separate component — noted), `data/navLinks.ts`,
all other components/hooks/data/CSS, all non-header sections.

### Verification (45/45 PASS, 0 console errors)
- `npx tsc --noEmit` — 0 errors; `npm run build` — succeeds (JS
  270.31 kB / CSS 36.04 kB); `npm run lint` — 0 errors, 3 pre-existing
  warnings (the first draft's transient 4th warning was fixed in-line).
- jsdom behavioral simulation on the production bundle (no browser in
  sandbox — desktop/mobile/keyboard verified at behavior level +
  minified-CSS inspection):
  - Desktop: skip link first focusable → `#main`; wordmark + caret;
    6 links 01–06; active home + `aria-current="true"`; quiet CTA
    (no `btn--primary`); hamburger aria wiring correct; closed at rest;
    `nav` landmark "Main"; old `.nav__cta` gone.
  - Mobile: open → expanded/label/`.open`/scroll-lock/focus-in/X-state;
    focus trap both directions (7 focusable entries); Escape, scrim
    click, and entry click all close with focus returned to the
    hamburger; body scroll restored.
  - Keyboard: skip link focusable; skip-link click not intercepted by
    smooth-scroll (native behavior preserved) while normal nav links
    still smooth-scroll.
  - Regression: all structural counts unchanged (8/6/5/3/4 + loader,
    cursor, typing, footer, 7 sections).
  - Built CSS: no `backdrop-filter` on any header rule; scrolled =
    solid `var(--bg)` no shadow; sheet = solid `var(--bg-card-2)` +
    visibility/opacity/transform; skip-link + `:focus-visible` rules;
    `logoCaretBlink`; mono indices; unfilled CTA; `scaleX(1)` underline.
- Documented env limit: no real-browser visual pass possible in sandbox
  (jsdom has no layout/media evaluation/native fragment navigation) —
  a visual check in a browser is the recommended first manual step
  before deploy.

### This checkpoint
- ZIP: `portfolio-backups/phase-07-header.zip` — index.html, script.js,
  style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06/07-NOTES.md + full react-app/ source (no
  node_modules, no dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates when
requested:
- Redesigning the next section (hero or footer are the usual
  follow-ups to a header pass).
- Resolving flagged content issues (email conflict, placeholder links,
  shared repo URL, CV file, testimonial initials).
- `prefers-reduced-motion` pass (would also cover the new caret blink).
- Real contact-form backend.

## Blocker (Phase 07)
None.
## Phase 08 — Hero: COMPLETE (verified)

### What was done
Redesigned the Hero only ("the masthead") — an editorial
composition built solely from content already in the source: mono
status kicker (real availability + `siteConfig.location`), the exact
role as H1 (original line breaks + accent span), his own one-liner
verbatim, the typing line (the identity, unchanged), two real
actions, and a personal byline ("Siyam Uzzaman — first-year CSE
student, CSE'30" — all real source facts). Set left in an asymmetric
7/5 grid beside the one real visual asset: the code card, now a
captioned `<figure>` ("stack — HTML5 · CSS3 · JavaScript · Shopify"
— the old floating badges' real names, preserved, not deleted).

**Removed (recorded decisions):** fake avatar portrait + rings (no
real photo exists — not a real asset); 3 orbs + the parallax effect;
hero stat trio (20+/15+/2+) — the complete 20/15/2/8 band remains in
the Stats section, nothing lost; "View Projects" repointed from the
shared placeholder GitHub repo URL (AUDIT-flagged) to the real
in-page `#projects`; code card de-glassified (solid `var(--bg-card)`,
no blur/shadow); actions restyled to the Phase-07 quiet-box language.
No claims, stats, personality, or positioning invented; no generic
copy; WhatsApp stays where it lives (About), not tripled.

### Files changed
- `src/components/Hero.tsx` — restructured (orb parallax effect,
  avatar, rings, badges, stat trio removed; kicker/byline/figure
  added).
- `src/styles/style.css` — §8 HERO rewritten in place; 768px hero
  rules rewritten (single column, **stays left-set — no centered
  mobile hero**); 480px hero rules reduced to the left-set actions
  stack. 1024px hero rules untouched and still apply.

Not touched: legacy originals (git-clean), `useTypingEffect`,
`typingPhrases`, `siteConfig`, `stats.ts`, all other components/hooks/
data/CSS blocks, all non-hero sections, AOS mechanism. (Two now-dead
Phase-06 selectors remain in that trailing block — harmless, block
left intact.)

### Verification (31/31 PASS, 0 console errors)
- `tsc` 0 errors; build succeeds (JS 267.16 kB — shrank vs Phase 07
  with the removed code; CSS 34.01 kB); lint 0 errors, 3
  pre-existing warnings.
- jsdom behavioral simulation of the production bundle: content
  exact (kicker/H1 lines+accent/subtitle verbatim/typing/byline/code
  card/figure caption); removals confirmed absent from DOM; Stats
  band intact (4 items); **actions tested** (View Projects →
  `#projects` smooth-scrolls on click; Email Me →
  `mailto:devs.siyam@gmail.com` native; no placeholder CTA);
  **responsive** verified in built CSS (7/5 base grid; 768 single
  column with no centering; 480 left-set stacked actions); no
  `backdrop-filter`/blur on any hero rule; code card solid;
  mono kicker/byline/caption; full regression (8/6/5/3/4/6 counts,
  Phase-07 header intact, loader/cursor/footer/sections).
- Documented env limit: no browser in sandbox — visual pass in a real
  browser recommended before deploy (same as Phase 07).

### This checkpoint
- ZIP: `portfolio-backups/phase-08-hero.zip` — index.html,
  script.js, style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06/07/08-NOTES.md + full react-app/ source (no
  node_modules, no dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates
when requested:
- Redesigning the next section (About or Footer are the natural
  follow-ups).
- Resolving flagged content issues (email conflict, placeholder
  links, shared repo URL on project cards, CV file, testimonial
  initials).
- `prefers-reduced-motion` pass.
- Real contact-form backend.

## Blocker (Phase 08)
None.
## Phase 09 — About: COMPLETE (verified)

### What was done
Redesigned the About section only ("the profile") — an editorial
spread instead of the standard portrait + bio pattern: his real words
as a statement (left, 7fr — mono kicker "First-year CSE student ·
Bangladesh", his greeting, both bio paragraphs verbatim, "Let's Talk"
→ real WhatsApp deep link) beside a technical index panel (right,
5fr — `// what I work on`: 01 Frontend "HTML · CSS · JavaScript ·
React.js" (his own bio sentence), 02 Shopify "Store design & Liquid
templating", 03 Responsive & UI "Mobile-first, modern UI", 04 Now
"CSE'30 — learning through projects" — plus his three principles,
verbatim, compacted from cards to rows). Every line is existing
source content; nothing invented; no generic/filler copy.

**Removed (recorded decisions):** fake avatar + profile column +
badge (no real photo exists in the repo); three info chips (content
redistributed to kicker/statement/rows — nothing lost); "Download CV"
(dead `#` link — an AUDIT-flagged open item; re-add when a real CV
exists); highlight cards → compact principle rows.

### Files changed
- `src/components/About.tsx` — restructured to statement + index
  `<aside>` panel.
- `src/styles/style.css` — §9 ABOUT rewritten in place; 3 dead about
  rules removed from the 768px block. 1024px gap rule and the 768px
  single-column rule kept and still apply (new layout stacks
  left-set).

Not touched: legacy originals (git-clean), skills/services data and
sections, all other components/hooks/data/CSS blocks, all
non-About sections, AOS mechanism. (One now-dead Phase-06 selector
remains in that trailing block — harmless, block intact.)

### Verification (26/26 PASS, 0 console errors)
- `tsc` 0 errors; build succeeds (JS 265.49 kB — shrank vs Phase 08;
  CSS 34.06 kB); lint 0 errors, 3 pre-existing warnings.
- jsdom behavioral simulation of the production bundle: content
  real & verbatim (kicker/greeting/both bios/index rows 01–04/
  principles/WhatsApp href exact); removals confirmed absent (no
  avatar/chips/highlights/SVG portrait/dead CV); composition
  (real `<aside>`, 7/5 asymmetric, bordered solid panel, mono
  identity labels); **responsive** verified in built CSS (768 single
  column left-set, 1024 tighter gap); zero blur/glow/shadow on about
  rules; full regression (8/6/5/3/4/6 counts, hero+header intact,
  loader/cursor/footer/sections).
- Documented env limit (as Phases 07/08): no real-browser visual pass
  possible in sandbox — browser check recommended before deploy.

### This checkpoint
- ZIP: `portfolio-backups/phase-09-about.zip` — index.html,
  script.js, style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06/07/08/09-NOTES.md + full react-app/ source (no
  node_modules, no dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates
when requested:
- Redesigning the next section (Skills or Services are natural
  follow-ups; Footer last).
- Resolving flagged content issues (email conflict, placeholder
  links, shared repo URL, CV file — re-add About's CV button once
  real, testimonial initials).
- `prefers-reduced-motion` pass.
- Real contact-form backend.

## Blocker (Phase 09)
None.
## Phase 10 — Skills: COMPLETE (verified)

### What was done
Redesigned the Skills section only ("the stack manifest") — the
generic 8-card grid with animated progress bars and fake percentages
(which never matched the displayed numbers — AUDIT-flagged) replaced
by ONE bordered manifest in the site's numbered-index language (Phase
07 header / Phase 09 About): the 9 genuinely supported skills,
grouped by the areas they actually cover, numbered 01–04, each skill
a mono code-style token.

- **Groups (real, source-verified):** 01 Frontend [HTML5, CSS3,
  JavaScript, React.js] · 02 UI & Responsive [UI/UX Design,
  Responsive Design] · 03 Shopify [Shopify, Liquid] · 04 Tools
  [GitHub]. React.js added — supported by his own bio sentence and
  the Phase 09 About index (no icon asset in source → empty
  `iconPaths`, icon-less like all tokens).
- **No "Currently Learning" group** — no such list exists in the
  source; none invented.
- **Fake proficiency deleted from model AND presentation** — `width`
  and `percent` removed from the `Skill` type and every data entry;
  no bar, fill, `data-width`, or `%` label anywhere in the section.
- **SkillCard.tsx deleted** (its only purpose was the fake bars);
  icons kept in data, not rendered (manifest is a code-style list).
- Section header keeps the real existing labels verbatim. Zero
  blur/glow/shadow/glass — solid panel, hairline tokens,
  border+color hover only.

### Files changed
- `src/types/content.ts` — `Skill`: −`width`, −`percent`, +`group`
  (+ `SkillGroup` union).
- `src/data/skills.ts` — 8 → 9 entries (React.js added), no
  proficiency fields, real `group` per entry, icon data preserved.
- `src/components/Skills.tsx` — rewritten as the manifest; decision
  log in file header.
- `src/components/SkillCard.tsx` — deleted.
- `src/styles/style.css` — §10 rewritten in place
  (`.skills__manifest` bordered panel; `.skills__group`/`-head`/
  `-num`/`-label`; `.skills__tokens`/`-token` mono hairline chips);
  media: @1024 head basis 170px, @768 groups stack (label above
  tokens) + tighter padding, @480 tokens 0.72rem — replacing all 3
  old `.skills__grid` lines. `.skills__bg` radial kept (existing).
  Phase-06 trailing block's `.skill-card__name` is now a dead
  selector — harmless, block intact (established convention).

Not touched: legacy originals (git-clean), all other sections/data/
components/hooks, AOS mechanism, useInView (still used by Stats).

### Verification (25/25 PASS, 0 console errors)
- `tsc` 0 errors; build succeeds (CSS 33.89 kB / JS 265.07 kB, 41
  files); lint 0 errors, 3 pre-existing warnings.
- jsdom behavioral simulation of the production bundle: manifest
  structure (1 panel / 4 numbered groups / 9 tokens / correct
  per-group membership / no "Currently Learning"); fake-proficiency
  removal (no `%` in section text, no bar/fill/inline width, model
  fields gone, no `skill-card__` rules in built CSS, component file
  deleted); identity (mono tokens, solid bordered panel, zero
  blur/shadow on skills rules, real header labels, h3 group
  headings); **responsive** verified in built CSS (768 stack / 480
  shrink / 1024 head basis — resolved against the actual media
  block); full regression (6/5/3/4 cards, 6 nav, all sections,
  loader/cursor/footer, AOS).
- Documented env limit (as Phases 07/08/09): no real-browser visual
  pass possible in sandbox — browser check recommended before deploy.

### This checkpoint
- ZIP: `portfolio-backups/phase-10-skills.zip` — index.html,
  script.js, style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06/07/08/09/10-NOTES.md + full react-app/ source (no
  node_modules, no dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates
when requested:
- Redesigning the next section (Projects or Services are natural
  follow-ups; Footer last).
- Resolving flagged content issues (email conflict, placeholder
  links, shared repo URL, CV file, testimonial initials).
- `prefers-reduced-motion` pass.
- Real contact-form backend.

## Blocker (Phase 10)
None.
## Phase 11 — Projects: COMPLETE (verified)

### What was done
Redesigned the Projects section only ("the work index") — verification-
first: the actual availability of proof (checked against the GitHub
API, 2026-09-18) determines the hierarchy instead of 6 identical cards
with dead "#" demo buttons and a shared, unrelated repo link (AUDIT
risks #3 + #8).

Reality verified: devssiyam's public repos are ONLY `portfolio` (this
site's real source) and `devs.siyam` (README only — no project code);
no GitHub Pages / no live deployment anywhere; zero image files in the
repo (no screenshots); the only "visuals" are the baseline's
per-project inline SVG wireframes. So the only verified public project
artifact is the portfolio's own source.

- **Featured case (01) — Personal Portfolio Website**: the one project
  with a verified public source → bordered panel + the real GitHub
  link (`github.com/devssiyam/portfolio`, new tab, `noopener
  noreferrer`).
- **Numbered index (02–06)**: the other five as rows in one bordered
  panel — mono `0N · Category`, title, verbatim description, mono
  stack tokens, real per-project schematic wireframe as a glyph marker
  (kept from baseline, not presented as a screenshot — none exist).
- **Factual footnote**: "The source for the other projects is not
  hosted as public repositories."
- Goal/problem/role/challenge/solution/result/case-study fields had no
  source content — nothing invented; no results/metrics added;
  descriptions are the existing source copy verbatim.
- Section header keeps the real labels verbatim; zero blur/glow/
  shadow/glass; interaction = row hover + AOS reveal (3D tilt removed
  with the cards; `useCardTilt` stays — Services/Testimonials use it).

### Files changed
- `src/types/content.ts` — `Project`: −`demoUrl`, `repoUrl` → optional
  (verified-target doc), `placeholderSvg` documented as glyph.
- `src/data/projects.ts` — verified-link pass (dead `#` demos and
  shared repo URL removed; one verified `repoUrl` on the portfolio
  entry); all content verbatim.
- `src/components/Projects.tsx` — rewritten as featured case +
  numbered index + factual footnote; decision log in file header.
- `src/components/ProjectCard.tsx` — deleted.
- `src/styles/style.css` — §11 rewritten in place (`.projects__case`,
  `.projects__tile`, `.projects__meta/-num/-title/-desc/-stack/-tag`,
  `.projects__index`, `.projects__row`, `.projects__note`); media:
  @1024 case padding, @768 case stacks + button below + tighter index,
  @480 glyph/tags shrink. All 3 old `.projects__grid` media lines
  replaced. Phase-06 trailing block's `.project-card__*` rules now
  dead selectors — harmless, block intact (established convention).

Not touched: legacy originals (git-clean), all other sections/data/
components/hooks, AOS mechanism, footer socials (pre-existing).

### Verification (36/36 PASS, 0 console errors)
- `tsc` 0 errors; build succeeds (CSS 34.23 kB / JS 265.19 kB, 40
  files); lint 0 errors, 3 pre-existing warnings.
- jsdom behavioral simulation of the production bundle: header labels
  verbatim; featured case (correct project, verbatim desc/stack, exact
  verified URL + `_blank` + safe rel, real glyph/color); index (5
  rows 02–06, all title/meta/desc verbatim, stacks verbatim, real
  per-row colors + glyphs); **link honesty** (exactly ONE link in the
  section = the verified repo; zero `#` links; no "Live Demo"; shared
  repo not linked; factual footnote present; no invented
  results/metrics); structure (no card grid/tilt, 6 projects exactly
  once, no `<img>` — none faked); identity (solid bordered panels,
  zero blur/shadow on projects rules, mono tokens/meta); **responsive**
  verified in built CSS (1024/768/480 — resolved against the actual
  media block); full regression (5/3/4 cards, 6 nav, 9 skill tokens,
  hero/about/header, sections, loader/cursor/footer).
- **Page-wide image + link audit**: 0 `<img>` elements anywhere (repo
  has no image files — consistent); 22 links total, **0 dead `#`/empty
  links left on the whole site** (AUDIT risk #3 fully resolved with
  Phase 09's CV removal; risk #8 resolved here).
- Documented env limit (as Phases 07–10): no real-browser visual pass
  possible in sandbox — browser check recommended before deploy.

### This checkpoint
- ZIP: `portfolio-backups/phase-11-projects.zip` — index.html,
  script.js, style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06/07/08/09/10/11-NOTES.md + full react-app/ source
  (no node_modules, no dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates
when requested:
- Redesigning the next section (Services or Testimonials/Stats are
  natural follow-ups; Footer last).
- Resolving flagged content issues (email conflict, placeholder CV —
  re-add when real, shared-repo footer social, testimonial initials).
- `prefers-reduced-motion` pass.
- Real contact-form backend.

## Blocker (Phase 11)
None.
## Phase 12 — Case Study: COMPLETE (verified)

### What was done
Created a case study ONLY where the gate was met: enough real,
verifiable information exists for exactly ONE project — the Personal
Portfolio Website (the only project with a verified public source,
per Phase 11's verification). All five other projects have
name/context/tags only — a case study for them would be filler, so
none created (not even stubs).

**One concise case file** inside the Phase 11 featured case (under a
hairline divider): `// case file` kicker + 3 mono-labeled dimensions:
- **Context** — "A single-page portfolio for a first-year CSE
  student, presenting his frontend and Shopify work." (site's own
  verbatim copy)
- **Role** — "Sole developer — the only author on the repository."
  (git-verified: 1 commit, 1 author)
- **Technical decisions** (4, each source-backed): no external JS
  libraries — typing/scroll-reveal/counters hand-rolled vanilla JS
  (AUDIT + source: single local script, no CDNs); one token-based
  `:root` stylesheet; inline SVG only — zero image files in the repo;
  now rebuilt in React (Vite + TypeScript) — the served build.

Tech (stack tokens) and Links (verified GitHub button) already live on
the case's identity row from Phase 11 — not duplicated. **Dimensions
with no source content (Problem, Approach, Challenges, Solution,
Result) are simply absent — never padded; zero metrics/numbers
invented.** Placed inside Projects: no new section, no nav change.

### Files changed
- `src/types/content.ts` — `Project`: + optional `caseStudy`
  (`context`, `role`, `technicalDecisions[]`) — "only when real" doc.
- `src/data/projects.ts` — portfolio entry gains the case file with
  per-line verification sources in comments; other entries unchanged.
- `src/components/Projects.tsx` — renders the case file only when
  `featured.caseStudy` exists (gate is structural); decision log
  extended.
- `src/styles/style.css` — §11 extended (`.projects__casestudy`,
  `.projects__cs-kicker/-label/-body/-list`, dash `li::before`);
  @768 case file stacks one column. No other media rules touched.

Not touched: legacy originals (git-clean), all other sections/data/
components/hooks, nav, AOS mechanism.

### Verification (32/32 PASS, 0 console errors)
- `tsc` 0 errors; build succeeds (CSS 35.35 kB / JS 266.41 kB, 40
  files); lint 0 errors, 3 pre-existing warnings.
- jsdom behavioral simulation: **gate** (exactly one case file, in the
  portfolio case, zero on index projects); **structure** (only
  Context/Role/Technical decisions + kicker; no invented dimension
  labels); **content** (all text verbatim from data and fully covered
  by the data file; 4 decisions verbatim; no metrics/numbers/
  improvement-verbs); **navigation** (`#projects` unique, case file
  reachable inside it, nav unchanged, nav click clean, DOM order
  case → index → footnote); **links** (still exactly one section link
  = verified repo, zero dead `#` site-wide); **identity** (mono
  labels/kicker/dashes, zero blur/shadow, hairline divider);
  **responsive** (768 stack + label spacing, Phase 11 768/480/1024
  invariants — resolved against the actual media block); **full
  regression** (Phase 11 case/index/footnote, 5/3/4/6/9 counts,
  hero/about/header, 0 `<img>`, sections/loader/cursor/footer).
- Documented env limit (as Phases 07–11): no real-browser visual pass
  possible in sandbox — browser check recommended before deploy.

### This checkpoint
- ZIP: `portfolio-backups/phase-12-case-study.zip` — index.html,
  script.js, style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06/07/08/09/10/11/12-NOTES.md + full react-app/
  source (no node_modules, no dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates
when requested:
- Redesigning the next section (Services or Testimonials/Stats are
  natural follow-ups; Footer last).
- Resolving flagged content issues (email conflict, placeholder CV —
  re-add when real, shared-repo footer social, testimonial initials).
- `prefers-reduced-motion` pass.
- Real contact-form backend.

## Blocker (Phase 12)
None.
## Phase 13 — Services: COMPLETE (verified)

### What was done
Redesigned the Services section only ("the two trades") — the 5
repetitive agency-cliché cards ("high-converting", "capture leads",
"boost sales", "A/B Testing Ready", "4K displays", 5× "Get Started")
replaced by the TWO TRADES his verbatim role names ("Frontend
Developer & Shopify Store Designer" — Hero H1):

- **Subtitle = his verbatim Hero sentence** — "I create modern,
  responsive, and visually attractive websites with clean UI and
  smooth user experience" (what I do + practical value, his own
  words; the filler "grow your online presence" subtitle is gone).
- **Two editorial trade blocks** (no card grid), each with exactly
  the three asked-for dimensions as mono-labeled rows:
  - **01 Frontend Development** — WHAT: "Websites and interfaces
    built with HTML, CSS, JavaScript, and React — store UIs, landing
    pages, forms, dashboards" (About-index stack verbatim + the four
    real project kinds). FOR: "Anyone who needs a site or interface
    built — the kinds of work are listed in the projects above"
    (Projects IS above Services — DOM-true). Tech: HTML · CSS ·
    JavaScript · React.js.
  - **02 Shopify Store Design** — WHAT: "Custom Shopify stores and
    product pages — store design and Liquid templating" (real
    project's own description + About index verbatim). FOR: "Store
    owners who want a custom build — not a stock theme." Tech:
    Shopify · Liquid.
- **One CTA** at the end — `// have a project in mind?` + "Let's
  Talk →" → real WhatsApp deep link (same pattern as About).

The three old extra cards fold in with nothing real lost (table in
PHASE-13-NOTES.md): Landing Page → a project kind; Responsive Web
Design → capability (skill + "Mobile-first" + verbatim "responsive");
UI Customization → capability (UI/UX Design skill + verbatim "clean
UI"). All cliché copy removed — no source evidence supported any of
it; no fake guarantees/numbers/outcomes. No invented services: a
third trade would have no source backing.

### Files changed
- `src/types/content.ts` — `Service`: −`description`, −`bullets`,
  +`what`, +`audience`, +`tech[]`; `iconPath` documented as
  unrendered legacy.
- `src/data/services.ts` — 5 → 2 entries (the two trades), every
  phrase source-backed with the evidence table in comments.
- `src/components/Services.tsx` — rewritten (header + two trade
  blocks + one CTA); decision log in file header.
- `src/components/ServiceCard.tsx` — deleted.
- `src/styles/style.css` — §12 rewritten in place
  (`.services__trades`, `.services__trade*`, `.services__tech-token`,
  `.services__cta*`); media: @1024 tighter gap (2 dead lines
  removed), @768 single column + breathing room + stacked CTA (2
  dead lines removed), @480 trade rows stack. Phase-06 trailing
  block's `.service-card__title/__link` now dead selectors —
  harmless, block intact (established convention).

Not touched: legacy originals (git-clean), all other sections/data/
components/hooks, nav, AOS mechanism.

### Verification (36/36 PASS, 0 console errors)
- `tsc` 0 errors; build succeeds (CSS 35.15 kB / JS 265.61 kB, 39
  files); lint 0 errors, 3 pre-existing warnings.
- jsdom behavioral simulation: **header** (real labels, verbatim Hero
  subtitle, filler gone); **trades** (exactly two, named by the
  verbatim role, numbered, old titles absent, all WHAT/FOR text
  verbatim from data, projects-above claim DOM-true); **tech**
  (real stacks only, nothing added); **clean** (zero agency clichés,
  zero fake guarantees/outcomes/numbers); **CTA** (exactly one, real
  WhatsApp link, mono kicker); **structure** (no card grid/icon
  tiles/svg chrome); **interaction** (AOS wired, no tilt); **built
  CSS** (§12 card rules gone — only the two Phase-06 dead
  display-font selectors remain by convention, zero blur/shadow,
  mono identity, hairline rows); **responsive** (1024/768/480 —
  resolved against the actual media block); **full regression**
  (Projects case + case file + 5 rows + footnote, 9 skill tokens / 4
  groups, 4/3/6 counts, hero/about/header, zero dead links, 0
  `<img>`, sections/loader/cursor/footer).
- Documented env limit (as Phases 07–12): no real-browser visual pass
  possible in sandbox — browser check recommended before deploy.

### This checkpoint
- ZIP: `portfolio-backups/phase-13-services.zip` — index.html,
  script.js, style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06/07/08/09/10/11/12/13-NOTES.md + full react-app/
  source (no node_modules, no dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates
when requested:
- Redesigning the next section (Testimonials or the Stats band are
  natural follow-ups; Footer last).
- Resolving flagged content issues (email conflict, placeholder CV —
  re-add when real, shared-repo footer social, testimonial initials,
  stat counters vs. real numbers).
- `prefers-reduced-motion` pass.
- Real contact-form backend.

## Blocker (Phase 13)
None.
## Phase 14 — Experience: COMPLETE (verified)

### What was done
Key finding: **no Experience section existed anywhere** (not in the
vanilla baseline, the app, the nav, or the migration plan) — so this
is a conditional creation (Phase 12 discipline): built only from
what is real, content decides the form.

The source supports exactly ONE period (the present) with two real
positions — so it is **not a timeline** (one period; a multi-node
timeline would be invented structure). One bordered panel with a
CURRENT marker (Hero-kicker pulsing dot language):

- **01 Computer Science and Engineering Student** — Period:
  `1st year · CSE'30` (the source's own words; no institution name
  exists anywhere in the source, so no organization line; no dates
  because the source gives none) · Work: three verbatim fragments —
  "continuously improving my development skills through projects
  and hands-on practice" + "HTML, CSS, JavaScript, and React.js" +
  "learning through projects".
- **02 Frontend Developer** — Period: `Current` · Work: verbatim
  "building modern, responsive, and user-friendly web experiences"
  + verbatim "available for freelance work, Bangladesh 🇧🇩" + the
  factual pointer "The work is in the projects section; this
  portfolio's source is public."

Placed between Skills and Projects (can → currently → proof →
offer); **not in the nav** (Stats precedent — 6 links untouched).
Header: tag "Experience", title "Where I Am", no subtitle (nothing
real to fill it with). Mono PERIOD/WORK labeled rows — the Services
trade language.

### Files changed
- `src/types/content.ts` — + `ExperienceEntry` (role/period/work,
  each documented as source-exact).
- `src/data/experience.ts` — (new) `experiencePeriod = 'Current'` +
  2 entries, per-line evidence table in comments.
- `src/components/Experience.tsx` — (new) CURRENT marker + dot +
  two numbered entries; decision log in file header.
- `src/App.tsx` — `<Experience />` between `<Skills />` and
  `<Projects />`.
- `src/styles/style.css` — new §10B EXPERIENCE block
  (`.experience__panel/__period/-dot/__entry/-head/-num/-role/
  -row/-label/-text`); media: @1024 panel padding, @768 rows stack
  + tighter entries, @480 head gap + role size. No dead selectors
  created.

Not touched: legacy originals (git-clean), all other sections/data/
components/hooks, nav, AOS mechanism.

### Verification (28/28 PASS, 0 console errors)
- `tsc` 0 errors; build succeeds (CSS 36.83 kB / JS 267.39 kB, 41
  files); lint 0 errors, 3 pre-existing warnings.
- jsdom behavioral simulation: section (exists once, DOM-ordered
  between Skills and Projects, tag/title exact, no subtitle);
  single CURRENT marker + dot; one panel, zero timeline elements;
  exactly two verbatim roles; periods exactly "1st year · CSE'30" /
  "Current"; **no invented dates** (no 4-digit years / "since" /
  "– present"), **no invented organization** (no
  university/institute/college/polytechnic), **no invented
  positions** (no intern/junior/senior/founder); all work text
  verbatim and ⊆ data file; nav untouched; identity (mono labels,
  solid panel, dot #22C55E + dotPulse, zero blur/shadow);
  **alignment** (consistent 64px label grid, baseline heads);
  **responsive** (1024 padding — minifier groups the rule with
  `.projects__case`, resolved against the actual media block / 768
  rows stack + tighter entries / 480 head + role adapt); AOS wired;
  **full regression** (8 anchor sections now, Projects case + case
  file + 5 rows, 2 services trades, 9 skill tokens, 4/3 counts,
  hero/about/header, 0 dead links, 0 `<img>`, loader/cursor/footer).
- Documented env limit (as Phases 07–13): no real-browser visual
  pass possible in sandbox — browser check recommended before
  deploy.

### This checkpoint
- ZIP: `portfolio-backups/phase-14-experience.zip` — index.html,
  script.js, style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06/07/08/09/10/11/12/13/14-NOTES.md + full
  react-app/ source (no node_modules, no dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates
when requested:
- Redesigning the next section (Testimonials or the Stats band are
  natural follow-ups; Footer last).
- Resolving flagged content issues (email conflict, placeholder CV —
  re-add when real, shared-repo footer social, testimonial
  initials/names, stat counters vs. real numbers).
- `prefers-reduced-motion` pass.
- Real contact-form backend.

## Blocker (Phase 14)
None.
## Phase 15 — Testimonials: COMPLETE (verified)

### What was done
Gate outcome: **zero genuine supplied testimonials → the section
was removed** (the task's explicit fallback). Each of the three
testimonials was checked against all available evidence:

| Testimonial | Why it fails |
|---|---|
| "Shakib Khan — E-Commerce Owner, BD" | avatar initial WRONG ('R'≠'S'); no business named; matches no listed project; name nowhere else in repo |
| "Khadizatul Kubra — Startup Founder, UK" | avatar initial WRONG ('S'≠'K'); no product/startup named; matches no listed project |
| "Sowkot Aziz — Business Owner, BD" | avatar initial WRONG ('M'≠'S'); no business named; matches no listed project |

Structural evidence: all three initials wrong (the AUDIT-flagged
telltale); **zero client/company corroboration anywhere in the
source** (the only "client" mention is the "15 Happy Clients"
counter itself); all six projects self-attributed; his own status
"Available for freelance work" (available, not engaged); quotes are
generic praise matching no real project; no external verification
path exists. Removing them (not repairing initials/wording — that
would dress up unverifiable attributions), and with none left, the
whole section went. No testimonial-style filler created as
replacement.

### Files removed
- `src/components/Testimonials.tsx`, `src/components/
  TestimonialCard.tsx`, `src/data/testimonials.ts` — deleted
- `src/types/content.ts` — `Testimonial` interface removed
- `src/App.tsx` — import + `<Testimonials />` removed
- `src/styles/style.css` — §14 TESTIMONIALS block (80 lines) + 4
  media lines (2×1024, 2×768) removed; section numbering now skips
  14 (gap kept, Phase 10B/14 convention); Phase-06 trailing block's
  3 `.testimonial-card__*` font selectors now dead — harmless,
  block intact (established convention)
- `src/hooks/useCardTilt.ts` — deleted as a consequence (last
  consumer was the TestimonialCard; Phases 11/13 removed the rest);
  two stale doc comments updated (Projects.tsx, tokens.ts)
- No nav change (never a nav item); Stats' "15 Happy Clients"
  untouched (own task — now even less visibly supported, carried in
  next-task list)

### Verification (20/20 PASS, 0 console errors)
- `tsc` 0 errors; build succeeds (CSS 35.32 kB / JS 264.45 kB —
  both shrank; 37 files); lint 0 errors, 3 pre-existing warnings.
- jsdom behavioral simulation: **removal** (no `#testimonials`,
  zero cards/grid, no "Client Love"/"What Clients Say", no
  `a[href="#testimonials"]`); **unsupported content gone** (all 3
  names + all 3 quotes absent; no filler created); **source** (3
  files + hook deleted, interface gone, no `cardTilt` in built
  bundle); **built CSS** (no live testimonials rules; exactly the
  three Phase-06 dead font selectors remain, by convention; none in
  any media block); **full regression** (7 anchor sections now, 6
  nav, Projects case + case file + 5 rows, 2 services trades,
  Experience 2 entries, 9 skill tokens / 4 groups, hero/about/
  header/stats/contact intact, 0 dead links, 0 `<img>`,
  loader/cursor/footer, AOS wired).
- Documented env limit (as Phases 07–14): no real-browser visual
  pass possible in sandbox.

### This checkpoint
- ZIP: `portfolio-backups/phase-15-testimonials.zip` — index.html,
  script.js, style.css (unmodified) + AUDIT.md + MIGRATION-PLAN.md +
  PHASE-03/04/05/06/07/08/09/10/11/12/13/14/15-NOTES.md + full
  react-app/ source (no node_modules, no dist).

### Next task
Awaiting instruction (not started, not assumed). Likely candidates
when requested:
- The Stats band (20+ / 15 / 2+ counters — "15 Happy Clients" now
  has no visible support at all; needs a real-numbers pass or
  removal), or the Contact section (fake form + email conflict),
  or Footer (last).
- Resolving flagged content issues (email conflict, placeholder CV
  — re-add when real, shared-repo footer social).
- `prefers-reduced-motion` pass.
- Real contact-form backend.

## Blocker (Phase 15)
None.

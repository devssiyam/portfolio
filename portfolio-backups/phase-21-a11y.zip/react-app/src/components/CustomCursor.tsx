import { useEffect, useRef } from 'react';
import { useMediaQuery } from '../hooks/useMediaQuery';

/**
 * Recreates initCursor() (module 2) exactly: same follower easing (0.12),
 * same hover-target selector, same window-leave/enter opacity toggle.
 * Unlike the original (which ran once for the page's lifetime), this uses
 * an explicit useEffect cleanup to cancel the rAF loop and remove listeners
 * on unmount — the single highest migration risk flagged in
 * MIGRATION-PLAN.md §6.1.
 */
export default function CustomCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const followerRef = useRef<HTMLDivElement>(null);
  // Phase 19: the cursor only exists where hover exists. The CSS already
  // hides it below 768px, but the rAF loop + listeners still ran on
  // touch devices — now the component bails out entirely for
  // non-fine-pointer devices (the audit's "width-gate bug", fixed in JS).
  const finePointer = useMediaQuery('(hover: hover) and (pointer: fine)');

  useEffect(() => {
    if (!finePointer) return;
    const cursor = cursorRef.current;
    const follower = followerRef.current;
    if (!cursor || !follower) return;

    let mouseX = 0;
    let mouseY = 0;
    let followerX = 0;
    let followerY = 0;
    let animFrame = 0;

    function onMouseMove(e: MouseEvent) {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursor!.style.left = mouseX + 'px';
      cursor!.style.top = mouseY + 'px';
      // Phase 19: resume the follower loop if it has idle-stopped.
      if (animFrame === 0) {
        animFrame = requestAnimationFrame(animateFollower);
      }
    }

    function animateFollower() {
      followerX += (mouseX - followerX) * 0.12;
      followerY += (mouseY - followerY) * 0.12;
      follower!.style.left = followerX + 'px';
      follower!.style.top = followerY + 'px';
      // Phase 19: idle-stop — once the follower has converged on the
      // cursor the loop parks itself (no rAF work while the pointer is
      // still); the next mousemove restarts it. Same visible behavior.
      if (Math.abs(mouseX - followerX) > 0.1 || Math.abs(mouseY - followerY) > 0.1) {
        animFrame = requestAnimationFrame(animateFollower);
      } else {
        animFrame = 0;
      }
    }
    animFrame = requestAnimationFrame(animateFollower);

    document.addEventListener('mousemove', onMouseMove);

    const hoverTargets = document.querySelectorAll(
      'a, button, .skill-card, .project-card, .service-card, .social-btn, input, textarea',
    );

    function onEnter() {
      cursor!.classList.add('cursor--active');
      follower!.classList.add('cursor-follower--active');
    }
    function onLeave() {
      cursor!.classList.remove('cursor--active');
      follower!.classList.remove('cursor-follower--active');
    }
    hoverTargets.forEach((el) => {
      el.addEventListener('mouseenter', onEnter);
      el.addEventListener('mouseleave', onLeave);
    });

    function onDocLeave() {
      cursor!.style.opacity = '0';
      follower!.style.opacity = '0';
    }
    function onDocEnter() {
      cursor!.style.opacity = '1';
      follower!.style.opacity = '1';
    }
    document.addEventListener('mouseleave', onDocLeave);
    document.addEventListener('mouseenter', onDocEnter);

    return () => {
      cancelAnimationFrame(animFrame);
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseleave', onDocLeave);
      document.removeEventListener('mouseenter', onDocEnter);
      hoverTargets.forEach((el) => {
        el.removeEventListener('mouseenter', onEnter);
        el.removeEventListener('mouseleave', onLeave);
      });
    };
  }, [finePointer]);

  // All hooks are called above; conditional render is safe here.
  if (!finePointer) return null;

  return (
    <>
      <div className="cursor" id="cursor" ref={cursorRef}></div>
      <div className="cursor-follower" id="cursorFollower" ref={followerRef}></div>
    </>
  );
}

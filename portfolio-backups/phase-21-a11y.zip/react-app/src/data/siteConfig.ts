// Central place for contact/social values that are not repeated card grids.
// NOTE (Phase 17, doc-level correction): the old header note claimed the two
// conflicting emails were "intentionally NOT resolved" — that is no longer
// true: Phase 16 resolved AUDIT risk #1, contactEmail is the real,
// git-verified address, and it is the single canonical email in the app.
export const siteConfig = {
  heroEmail: 'devs.siyam@gmail.com',
  // Phase 16: the old 'devs.siyam@email.com' had a non-existent TLD
  // (AUDIT risk #1 — the conflicting address). This is the real one:
  // verified as his committed git author address
  // (git log: Siyam Uzzaman <devs.siyam@gmail.com>) and the same
  // address the Hero's Email Me button has always used.
  contactEmail: 'devs.siyam@gmail.com',
  whatsappHref: 'whatsapp://send?phone=01330585129',
  location: 'Bangladesh 🇧🇩',
  responseTime: 'Within 24 hours',
  cvHref: '#', // "Download CV" — no real file target in the original markup
  social: {
    // Phase 16: the profile (verified real via the GitHub API in
    // Phase 11) instead of the old repo URL — a contact link should
    // point at the person, not at the old portfolio repo.
    github: 'https://github.com/devssiyam',
    linkedin: 'https://www.linkedin.com/in/siyam-uzzaman',
    facebook: 'https://web.facebook.com/profile.php?id=61567791733944',
    instagram: 'https://www.instagram.com/siyam_uzzaman',
  },
};

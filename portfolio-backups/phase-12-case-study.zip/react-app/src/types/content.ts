export interface NavLink {
  href: string;
  label: string;
}

export type SkillGroup = 'Frontend' | 'UI & Responsive' | 'Shopify' | 'Tools';

export interface Skill {
  name: string;
  colorVar: string;
  /** SVG path data (single <path>) or a full inline SVG override for icons that need it.
   *  Empty for skills with no icon asset in the source. */
  iconPaths: string[];
  iconViewBox: string;
  /** Whether the icon paths should render with fill="currentColor" set on the <svg> itself. */
  fillOnSvg: boolean;
  /** The real area this skill belongs to (Phase 10 — the grouping the actual
   *  skill set supports). */
  group: SkillGroup;
}

export interface Project {
  title: string;
  description: string;
  tags: string[];
  category: string;
  colorVar: string;
  /** Verified public source repository — Phase 11: set ONLY when the repo is
   *  real, public, and actually contains the work (checked against the
   *  GitHub API). Dead "#" demo links and the shared placeholder repo URL
   *  were removed; no link renders without a verified target. */
  repoUrl?: string;
  /** Per-project schematic wireframe (real baseline asset) — rendered as a
   *  glyph marker, not presented as a screenshot (no screenshots exist in
   *  the source). */
  placeholderSvg: string;
  /** Phase 12 — case study, rendered ONLY when it exists. Contains only
   *  dimensions with real, source-verified content for this project; the
   *  usual case-study shape is not padded (missing dimensions are simply
   *  absent, never invented). No project without a verified artifact has
   *  one. */
  caseStudy?: {
    context: string;
    role: string;
    technicalDecisions: string[];
  };
}

export interface Service {
  number: string;
  title: string;
  description: string;
  bullets: string[];
  iconPath: string;
}

export interface Stat {
  target: number;
  label: string;
}

export interface Testimonial {
  quote: string;
  authorName: string;
  authorRole: string;
  avatarInitial: string;
  avatarColorVar: string;
}
